package com.bluelock.entity;

import com.bluelock.game.BLCharacter;
import com.bluelock.game.PlayerState;
import com.bluelock.net.Net;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Круглый футбольный мяч. Физика считается на сервере каждый тик:
 * гравитация, сопротивление воздуха, отскоки, трение о землю, закрутка (эффект Магнуса).
 * Дриблинг: игрок, бегущий в мяч, "подталкивает" его перед собой.
 */
public class BallEntity extends Entity {
	public static final double RADIUS = 0.25;

	private static final double GRAVITY = 0.045;
	private static final double MAX_SPEED = 2.4;

	// ---- серверное состояние ----
	private float spin = 0f;
	private int touchCooldown = 0;
	private final Map<UUID, Vec3> lastPlayerPos = new HashMap<>();

	// ---- клиентское состояние (визуальное вращение при качении) ----
	public final Quaternionf rot = new Quaternionf();
	public final Quaternionf rotO = new Quaternionf();
	private double lastX;
	private double lastZ;
	private boolean firstClientTick = true;

	public BallEntity(EntityType<? extends BallEntity> type, Level level) {
		super(type, level);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
	}

	@Override
	protected void readAdditionalSaveData(CompoundTag tag) {
	}

	@Override
	protected void addAdditionalSaveData(CompoundTag tag) {
	}

	@Override
	public boolean isPickable() {
		return true;
	}

	@Override
	public boolean canBeCollidedWith() {
		return false;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	/** ЛКМ по мячу = обычный удар в направлении взгляда. */
	@Override
	public boolean hurt(DamageSource source, float amount) {
		if (!level().isClientSide && source.getEntity() instanceof ServerPlayer player) {
			playerKick(player, 0.55, 0);
			return true;
		}
		return false;
	}

	/** Присев + ПКМ по мячу — убрать мяч. */
	@Override
	public InteractionResult interact(Player player, InteractionHand hand) {
		if (player.isShiftKeyDown()) {
			if (!level().isClientSide) {
				discard();
			}
			return InteractionResult.sidedSuccess(level().isClientSide);
		}
		return InteractionResult.PASS;
	}

	// ------------------------------------------------------------------ tick

	@Override
	public void tick() {
		super.tick();
		if (level().isClientSide) {
			updateRoll();
			return;
		}
		dribble();
		physics();
	}

	private void updateRoll() {
		rotO.set(rot);
		double x = getX();
		double z = getZ();
		if (firstClientTick) {
			firstClientTick = false;
			lastX = x;
			lastZ = z;
			return;
		}
		double dx = x - lastX;
		double dz = z - lastZ;
		lastX = x;
		lastZ = z;
		double len = Math.sqrt(dx * dx + dz * dz);
		if (len > 1.0E-4) {
			Quaternionf delta = new Quaternionf().fromAxisAngleRad(
				(float) (dz / len), 0f, (float) (-dx / len), (float) (len / RADIUS));
			delta.mul(rot);
			rot.set(delta);
			rot.normalize();
		}
	}

	private void physics() {
		Vec3 v = getDeltaMovement();

		if (isInWater()) {
			v = v.scale(0.88).add(0, 0.035, 0);
		} else {
			v = v.add(0, -GRAVITY, 0);
		}

		// закрутка: в воздухе искривляет траекторию
		if (Math.abs(spin) > 0.01f && !onGround()) {
			double h = Math.sqrt(v.x * v.x + v.z * v.z);
			v = v.yRot(spin * 0.05f * (float) Math.min(1.0, h * 2.0));
			spin *= 0.985f;
		} else if (onGround()) {
			spin *= 0.8f;
		}

		// сопротивление воздуха
		v = new Vec3(v.x * 0.995, v.y * 0.998, v.z * 0.995);

		Vec3 before = v;
		setDeltaMovement(v);
		move(MoverType.SELF, v);
		Vec3 after = getDeltaMovement();

		double nx = after.x;
		double ny = after.y;
		double nz = after.z;
		boolean bounced = false;

		if (horizontalCollision) {
			if (Math.abs(before.x) > 0.02 && Math.abs(after.x) < 1.0E-5) {
				nx = -before.x * 0.6;
				bounced = true;
			}
			if (Math.abs(before.z) > 0.02 && Math.abs(after.z) < 1.0E-5) {
				nz = -before.z * 0.6;
				bounced = true;
			}
		}

		if (verticalCollision) {
			if (before.y < 0) {
				if (Math.abs(before.y) > 0.12) {
					ny = -before.y * 0.62;
					bounced = true;
				} else {
					ny = 0;
				}
			} else if (before.y > 0) {
				ny = -before.y * 0.3;
				bounced = true;
			}
		}

		// трение при качении по земле
		if (onGround() && ny <= 0.01) {
			double friction = level().getBlockState(BlockPos.containing(getX(), getY() - 0.05, getZ()))
				.getBlock().getFriction();
			double factor = Math.min(0.996, 0.975 + (friction - 0.6) * 0.05);
			nx *= factor;
			nz *= factor;
			if (nx * nx + nz * nz < 1.0E-5) {
				nx = 0;
				nz = 0;
			}
		}

		if (bounced) {
			double impact = Math.max(Math.abs(before.y), Math.max(Math.abs(before.x), Math.abs(before.z)));
			if (impact > 0.15) {
				level().playSound(null, getX(), getY(), getZ(), SoundEvents.SLIME_SQUISH_SMALL,
					SoundSource.NEUTRAL, (float) Math.min(1.0, impact), 1.2f);
			}
		}

		setDeltaMovement(nx, ny, nz);
	}

	// -------------------------------------------------------------- дриблинг

	private void dribble() {
		long now = level().getGameTime();
		List<ServerPlayer> players = level().getEntitiesOfClass(
			ServerPlayer.class, getBoundingBox().inflate(4.0, 2.0, 4.0), pl -> !pl.isSpectator());

		lastPlayerPos.keySet().removeIf(id -> players.stream().noneMatch(pl -> pl.getUUID().equals(id)));

		for (ServerPlayer p : players) {
			Vec3 cur = p.position();
			Vec3 last = lastPlayerPos.put(p.getUUID(), cur);
			Vec3 pv = last == null ? Vec3.ZERO : cur.subtract(last);
			double pvh = Math.sqrt(pv.x * pv.x + pv.z * pv.z);
			if (pvh > 0.7) {
				pv = Vec3.ZERO;
				pvh = 0;
			}
			if (touchCooldown > 0) {
				continue;
			}

			BLCharacter ch = PlayerState.character(p);
			PlayerState.Data data = PlayerState.data(p);
			Vec3 bp = position();
			double hdist = Math.sqrt((bp.x - cur.x) * (bp.x - cur.x) + (bp.z - cur.z) * (bp.z - cur.z));
			double dy = bp.y - cur.y;
			Vec3 vel = getDeltaMovement();

			// --- "магнит": мяч прилипает к ногам (режим монстра, спринт и т.п.)
			if (data.magnetUntil > now && hdist < 4.0 && dy > -1.0 && dy < 2.0) {
				Vec3 look = p.getLookAngle();
				double fl = Math.sqrt(look.x * look.x + look.z * look.z);
				Vec3 fwd = fl < 1.0E-4 ? new Vec3(0, 0, 1) : new Vec3(look.x / fl, 0, look.z / fl);
				Vec3 side = new Vec3(-fwd.z, 0, fwd.x);
				double weave = data.weave ? Math.sin(now * 0.55) * data.weaveAmp : 0.0;
				Vec3 target = cur.add(fwd.scale(0.75)).add(side.scale(weave));
				Vec3 diff = target.subtract(bp);
				double vy = Math.max(-0.1, Math.min(0.2, diff.y * 0.4));
				setDeltaMovement(diff.x * 0.6, vy, diff.z * 0.6);
				continue;
			}

			// --- Наги: идеальный первый контакт (трап) для быстрых мячей
			if (ch == BLCharacter.NAGI) {
				double speed = vel.length();
				if (speed > 0.3 && hdist < 1.8 && dy > -0.5 && dy < 1.7) {
					Vec3 look = p.getLookAngle();
					Vec3 feet = cur.add(look.x * 0.5, 0, look.z * 0.5);
					Vec3 toFeet = feet.subtract(bp).scale(0.25);
					setDeltaMovement(vel.x * 0.12 + toFeet.x, 0.0, vel.z * 0.12 + toFeet.z);
					touchCooldown = 4;
					if (level() instanceof ServerLevel sl) {
						sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.25, getZ(), 6, 0.15, 0.15, 0.15, 0.02);
					}
					continue;
				}
			}

			// --- обычный дриблинг: подталкиваем мяч по ходу движения
			double control = ch != null ? ch.control : 0.5;
			double range = 0.95 + control * 0.25;
			if (hdist < range && Math.abs(dy) < 1.3) {
				if (pvh > 0.03) {
					double dirX = pv.x / pvh;
					double dirZ = pv.z / pvh;
					double relX = hdist < 1.0E-4 ? dirX : (bp.x - cur.x) / hdist;
					double relZ = hdist < 1.0E-4 ? dirZ : (bp.z - cur.z) / hdist;
					if (relX * dirX + relZ * dirZ > -0.35) {
						double targetSpeed = pvh * (p.isSprinting() ? 1.18 : 1.12) + 0.03;
						double blend = 0.30 + 0.35 * control;
						double nvx = vel.x + (dirX * targetSpeed - vel.x) * blend;
						double nvz = vel.z + (dirZ * targetSpeed - vel.z) * blend;
						setDeltaMovement(nvx, vel.y, nvz);
						if (now % 6 == 0) {
							level().playSound(null, getX(), getY(), getZ(), SoundEvents.WOOL_HIT,
								SoundSource.NEUTRAL, 0.25f, 1.4f);
						}
					}
				} else if (hdist < 0.35) {
					// стоим вплотную — мягко выдавливаем мяч, чтобы не сидел внутри игрока
					double relX = hdist < 1.0E-4 ? 1.0 : (bp.x - cur.x) / hdist;
					double relZ = hdist < 1.0E-4 ? 0.0 : (bp.z - cur.z) / hdist;
					setDeltaMovement(vel.x + relX * 0.05, vel.y, vel.z + relZ * 0.05);
				}
			}
		}

		if (touchCooldown > 0) {
			touchCooldown--;
		}
	}

	// ------------------------------------------------------------ публичное API

	/** Задать скорость мячу ("удар"). Ограничивает максимальную скорость. */
	public void launch(Vec3 velocity, float spinValue) {
		double len = velocity.length();
		if (len > MAX_SPEED) {
			velocity = velocity.scale(MAX_SPEED / len);
			len = MAX_SPEED;
		}
		setDeltaMovement(velocity);
		this.spin = spinValue;
		this.touchCooldown = 14;
		this.hasImpulse = true;
		if (!level().isClientSide) {
			level().playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_ATTACK_KNOCKBACK,
				SoundSource.PLAYERS, (float) Math.min(1.0, 0.3 + len * 0.4), 0.9f + random.nextFloat() * 0.2f);
			if (len > 1.2 && level() instanceof ServerLevel sl) {
				sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 0.25, getZ(), 6, 0.1, 0.1, 0.1, 0.02);
			}
		}
	}

	/** Мягкая остановка + подкат к ногам. */
	public void trapTo(Vec3 feetPos) {
		setPos(feetPos.x, feetPos.y, feetPos.z);
		setDeltaMovement(Vec3.ZERO);
		this.spin = 0f;
		this.touchCooldown = 3;
	}

	public void setSpin(float value) {
		this.spin = value;
	}

	public static BallEntity nearest(Player p, double reach) {
		Vec3 c = p.position().add(0, 0.9, 0);
		List<BallEntity> list = p.level().getEntitiesOfClass(BallEntity.class, new AABB(c, c).inflate(reach));
		BallEntity best = null;
		double bestDist = reach * reach;
		for (BallEntity b : list) {
			double d = b.position().add(0, RADIUS, 0).distanceToSqr(c);
			if (d <= bestDist) {
				bestDist = d;
				best = b;
			}
		}
		return best;
	}

	public static final int KICK_SHOT = 0;
	public static final int KICK_PASS = 1;
	public static final int KICK_LOB = 2;

	/** Удар игрока: тип (удар/пас/навес) и сила 0..1. Анимация проигрывается и при промахе. */
	public static boolean playerKick(ServerPlayer p, double power, int type) {
		BLCharacter ch = PlayerState.character(p);
		double mult = ch != null ? ch.power : 1.0;
		double accuracy = ch != null ? ch.accuracy : 0.7;

		Net.sendAnim(p, (type == KICK_SHOT && power > 0.7) ? Net.ANIM_POWER : Net.ANIM_KICK);

		BallEntity ball = nearest(p, 3.0);
		if (ball == null) {
			return false;
		}

		Vec3 look = p.getLookAngle();
		double fl = Math.sqrt(look.x * look.x + look.z * look.z);
		Vec3 flat = fl < 1.0E-4 ? new Vec3(0, 0, 1) : new Vec3(look.x / fl, 0, look.z / fl);

		Vec3 dir;
		double speed;
		switch (type) {
			case KICK_PASS -> {
				dir = flat.add(0, 0.06, 0).normalize();
				speed = 0.45 + 0.9 * power;
			}
			case KICK_LOB -> {
				dir = flat.scale(0.80).add(0, 0.62, 0).normalize();
				speed = 0.7 + 0.8 * power;
			}
			default -> {
				dir = new Vec3(look.x, Math.max(look.y, -0.05) + 0.08, look.z).normalize();
				speed = 0.55 + 1.55 * power * mult;
			}
		}

		double scatter = (1.0 - accuracy) * 0.05;
		if (scatter > 0) {
			dir = dir.add(
				ball.random.nextGaussian() * scatter,
				ball.random.nextGaussian() * scatter * 0.5,
				ball.random.nextGaussian() * scatter).normalize();
		}

		// удар отключает "магнит" на время, чтобы мяч мог улететь
		PlayerState.data(p).magnetUntil = 0;
		ball.launch(dir.scale(speed), 0f);
		return true;
	}
}
