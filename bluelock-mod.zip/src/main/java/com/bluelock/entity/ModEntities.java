package com.bluelock.entity;

import com.bluelock.BlueLockMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
	public static EntityType<BallEntity> BALL;

	private ModEntities() {}

	public static void register() {
		BALL = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			BlueLockMod.id("football"),
			EntityType.Builder.<BallEntity>of(BallEntity::new, MobCategory.MISC)
				.sized(0.5f, 0.5f)
				.clientTrackingRange(10)
				.updateInterval(1)
				.fireImmune()
				.build("football")
		);
	}
}
