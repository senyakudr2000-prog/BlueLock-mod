package com.bluelock.item;

import com.bluelock.BlueLockMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public final class ModItems {
	public static Item FOOTBALL;
	public static Item MENU;

	private ModItems() {}

	public static void register() {
		FOOTBALL = Registry.register(BuiltInRegistries.ITEM, BlueLockMod.id("football"),
			new FootballItem(new Item.Properties().stacksTo(1)));
		MENU = Registry.register(BuiltInRegistries.ITEM, BlueLockMod.id("menu"),
			new MenuItem(new Item.Properties().stacksTo(1)));

		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
			entries.accept(FOOTBALL);
			entries.accept(MENU);
		});
	}
}
