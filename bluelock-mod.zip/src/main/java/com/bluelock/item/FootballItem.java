package com.bluelock.item;

import com.bluelock.entity.BallEntity;
import com.bluelock.entity.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** ПКМ по блоку — ставит мяч. Предмет не расходуется. */
public class FootballItem extends Item {
	public FootballItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Level level = context.getLevel();
		if (level.isClientSide) {
			return InteractionResult.SUCCESS;
		}
		BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
		BallEntity ball = ModEntities.BALL.create(level);
		if (ball == null) {
			return InteractionResult.FAIL;
		}
		ball.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
		level.addFreshEntity(ball);
		return InteractionResult.CONSUME;
	}
}
