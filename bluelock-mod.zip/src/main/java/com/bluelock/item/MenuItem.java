package com.bluelock.item;

import com.bluelock.BlueLockMod;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** ПКМ — открывает меню выбора персонажа (удобно на телефоне, без клавиатуры). */
public class MenuItem extends Item {
	public MenuItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (level.isClientSide) {
			BlueLockMod.OPEN_MENU.run();
		}
		return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
	}
}
