package com.bluelock.client;

import com.bluelock.BlueLockMod;
import com.bluelock.entity.BallEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Рисует настоящую сферу (а не куб) и вращает её по направлению качения. */
public class BallRenderer extends EntityRenderer<BallEntity> {
	private static final ResourceLocation TEXTURE = BlueLockMod.id("textures/entity/football.png");
	private static final int LON = 16;
	private static final int LAT = 10;

	public BallRenderer(EntityRendererProvider.Context context) {
		super(context);
		this.shadowRadius = 0.22f;
	}

	@Override
	public ResourceLocation getTextureLocation(BallEntity entity) {
		return TEXTURE;
	}

	@Override
	public void render(BallEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
					   MultiBufferSource buffer, int packedLight) {
		poseStack.pushPose();
		poseStack.translate(0.0, BallEntity.RADIUS, 0.0);

		Quaternionf q = new Quaternionf(entity.rotO).slerp(entity.rot, partialTick);
		VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
		PoseStack.Pose pose = poseStack.last();
		float r = (float) BallEntity.RADIUS;

		for (int i = 0; i < LAT; i++) {
			double phi0 = Math.PI * i / LAT - Math.PI / 2;
			double phi1 = Math.PI * (i + 1) / LAT - Math.PI / 2;
			float v0 = 1f - (float) i / LAT;
			float v1 = 1f - (float) (i + 1) / LAT;
			for (int j = 0; j < LON; j++) {
				double th0 = 2 * Math.PI * j / LON;
				double th1 = 2 * Math.PI * (j + 1) / LON;
				float u0 = (float) j / LON;
				float u1 = (float) (j + 1) / LON;
				vertex(vc, pose, q, r, phi0, th0, u0, v0, packedLight);
				vertex(vc, pose, q, r, phi0, th1, u1, v0, packedLight);
				vertex(vc, pose, q, r, phi1, th1, u1, v1, packedLight);
				vertex(vc, pose, q, r, phi1, th0, u0, v1, packedLight);
			}
		}

		poseStack.popPose();
		super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
	}

	private static void vertex(VertexConsumer vc, PoseStack.Pose pose, Quaternionf q, float r,
							   double phi, double theta, float u, float v, int light) {
		// точка на единичной сфере; вращаем сами вершины, а нормали берём уже повёрнутые,
		// поэтому освещение остаётся "от солнца", а не крутится вместе с мячом
		Vector3f p = new Vector3f(
			(float) (Math.cos(phi) * Math.cos(theta)),
			(float) Math.sin(phi),
			(float) (Math.cos(phi) * Math.sin(theta)));
		q.transform(p);
		vc.addVertex(pose, p.x * r, p.y * r, p.z * r)
			.setColor(255, 255, 255, 255)
			.setUv(u, v)
			.setOverlay(OverlayTexture.NO_OVERLAY)
			.setLight(light)
			.setNormal(pose, p.x, p.y, p.z);
	}
}
