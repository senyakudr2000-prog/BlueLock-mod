package com.bluelock.client;

import com.bluelock.net.Net;
import net.minecraft.client.model.PlayerModel;

import java.util.HashMap;
import java.util.Map;

/**
 * Анимации ног/тела игрока при ударе, финте, рывке, приёме мяча.
 * Применяются миксином к модели игрока после стандартной анимации.
 */
public final class ClientAnims {
	private ClientAnims() {}

	private static final class Anim {
		final int type;
		final int start;
		final float duration;

		Anim(int type, int start, float duration) {
			this.type = type;
			this.start = start;
			this.duration = duration;
		}
	}

	private static final Map<Integer, Anim> ANIMS = new HashMap<>();

	public static void start(int entityId, int type, int tickCount) {
		float duration = switch (type) {
			case Net.ANIM_POWER -> 14f;
			case Net.ANIM_STEP -> 14f;
			case Net.ANIM_DASH -> 40f;
			case Net.ANIM_TRAP -> 12f;
			default -> 10f;
		};
		ANIMS.put(entityId, new Anim(type, tickCount, duration));
	}

	private static float lerp(float a, float b, float t) {
		return a + (b - a) * t;
	}

	public static void apply(PlayerModel<?> m, int entityId, float ageInTicks) {
		Anim a = ANIMS.get(entityId);
		if (a == null) {
			return;
		}
		float t = (ageInTicks - a.start) / a.duration;
		if (t > 1f) {
			ANIMS.remove(entityId);
			return;
		}
		if (t < 0f) {
			return;
		}

		switch (a.type) {
			case Net.ANIM_KICK, Net.ANIM_POWER -> {
				float amp = a.type == Net.ANIM_POWER ? 1.25f : 1.0f;
				float leg;
				if (t < 0.3f) {
					leg = lerp(0f, 0.8f, t / 0.3f);
				} else if (t < 0.55f) {
					leg = lerp(0.8f, -1.5f * amp, (t - 0.3f) / 0.25f);
				} else {
					leg = lerp(-1.5f * amp, 0f, (t - 0.55f) / 0.45f);
				}
				m.rightLeg.xRot = leg;
				m.rightArm.xRot = -leg * 0.5f;
				m.leftArm.xRot = leg * 0.5f;
				if (a.type == Net.ANIM_POWER) {
					m.leftArm.zRot = -0.5f;
					m.rightArm.zRot = 0.5f;
					m.body.xRot = -0.15f * (1f - Math.abs(t - 0.5f) * 2f);
				}
			}
			case Net.ANIM_STEP -> {
				float s = (float) Math.sin(t * Math.PI * 4.0);
				m.rightLeg.xRot = s * 0.9f;
				m.leftLeg.xRot = -s * 0.9f;
				m.rightLeg.zRot = s * 0.4f;
				m.leftLeg.zRot = -s * 0.4f;
				m.rightArm.xRot = -s * 0.7f;
				m.leftArm.xRot = s * 0.7f;
			}
			case Net.ANIM_DASH -> {
				float s = (float) Math.sin(ageInTicks * 1.4f);
				m.body.xRot = 0.45f;
				m.rightLeg.xRot = s * 1.3f;
				m.leftLeg.xRot = -s * 1.3f;
				m.rightArm.xRot = -s * 1.3f;
				m.leftArm.xRot = s * 1.3f;
			}
			case Net.ANIM_TRAP -> {
				float s = (float) Math.sin(t * Math.PI);
				m.rightLeg.xRot = -0.9f * s;
				m.rightArm.zRot = 0.6f * s;
				m.leftArm.zRot = -0.6f * s;
			}
			default -> {
			}
		}

		// наложенные слои (штаны, рукава, куртка) копируют части тела — обновим их
		m.leftPants.copyFrom(m.leftLeg);
		m.rightPants.copyFrom(m.rightLeg);
		m.leftSleeve.copyFrom(m.leftArm);
		m.rightSleeve.copyFrom(m.rightArm);
		m.jacket.copyFrom(m.body);
	}
}
