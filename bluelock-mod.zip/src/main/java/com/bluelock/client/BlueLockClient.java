package com.bluelock.client;

import com.bluelock.BlueLockMod;
import com.bluelock.entity.ModEntities;
import com.bluelock.net.Net;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.lwjgl.glfw.GLFW;

public class BlueLockClient implements ClientModInitializer {
	private static final String CATEGORY = "key.categories.bluelock";

	public static KeyMapping SHOOT;
	public static KeyMapping PASS;
	public static KeyMapping LOB;
	public static KeyMapping TRAP;
	public static KeyMapping SKILL1;
	public static KeyMapping SKILL2;
	public static KeyMapping SKILL3;
	public static KeyMapping MENU;

	/** Сколько тиков зажат удар (0..20). */
	public static int charge = 0;

	private static KeyMapping key(String name, int glfwKey) {
		return KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.bluelock." + name, InputConstants.Type.KEYSYM, glfwKey, CATEGORY));
	}

	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(ModEntities.BALL, BallRenderer::new);

		SHOOT = key("shoot", GLFW.GLFW_KEY_G);
		PASS = key("pass", GLFW.GLFW_KEY_V);
		LOB = key("lob", GLFW.GLFW_KEY_B);
		TRAP = key("trap", GLFW.GLFW_KEY_R);
		SKILL1 = key("skill1", GLFW.GLFW_KEY_Z);
		SKILL2 = key("skill2", GLFW.GLFW_KEY_X);
		SKILL3 = key("skill3", GLFW.GLFW_KEY_C);
		MENU = key("menu", GLFW.GLFW_KEY_M);

		BlueLockMod.OPEN_MENU = () -> Minecraft.getInstance().setScreen(new CharacterScreen());

		ClientPlayNetworking.registerGlobalReceiver(Net.SyncPayload.TYPE,
			(payload, ctx) -> ClientState.apply(payload));
		ClientPlayNetworking.registerGlobalReceiver(Net.AnimPayload.TYPE, (payload, ctx) -> {
			if (ctx.client().level == null) {
				return;
			}
			Entity e = ctx.client().level.getEntity(payload.entityId());
			if (e != null) {
				ClientAnims.start(e.getId(), payload.anim(), e.tickCount);
			}
		});

		ClientTickEvents.END_CLIENT_TICK.register(BlueLockClient::tick);
		HudRenderCallback.EVENT.register((graphics, tickDelta) -> Hud.render(graphics));
	}

	private static void send(int action, int arg) {
		ClientPlayNetworking.send(new Net.ActionPayload(action, arg));
	}

	private static void tick(Minecraft mc) {
		if (mc.player == null) {
			charge = 0;
			return;
		}

		while (MENU.consumeClick()) {
			if (mc.screen == null) {
				mc.setScreen(new CharacterScreen());
			}
		}

		if (mc.screen != null) {
			charge = 0;
			// сбрасываем "накопленные" нажатия, пока открыт экран
			while (PASS.consumeClick()) { }
			while (LOB.consumeClick()) { }
			while (TRAP.consumeClick()) { }
			while (SKILL1.consumeClick()) { }
			while (SKILL2.consumeClick()) { }
			while (SKILL3.consumeClick()) { }
			while (SHOOT.consumeClick()) { }
			return;
		}

		// удар: зажми для силы, отпусти — удар
		if (SHOOT.isDown()) {
			charge = Math.min(charge + 1, 20);
		} else if (charge > 0) {
			send(Net.ACT_SHOOT, Math.max(30, charge * 5));
			charge = 0;
		}
		while (SHOOT.consumeClick()) { }

		while (PASS.consumeClick()) {
			send(Net.ACT_PASS, 0);
		}
		while (LOB.consumeClick()) {
			send(Net.ACT_LOB, 0);
		}
		while (TRAP.consumeClick()) {
			send(Net.ACT_TRAP, 0);
		}
		while (SKILL1.consumeClick()) {
			send(Net.ACT_SKILL, 0);
		}
		while (SKILL2.consumeClick()) {
			send(Net.ACT_SKILL, 1);
		}
		while (SKILL3.consumeClick()) {
			send(Net.ACT_SKILL, 2);
		}
	}
}
