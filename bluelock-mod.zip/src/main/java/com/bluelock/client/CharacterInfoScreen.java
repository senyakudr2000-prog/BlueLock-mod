package com.bluelock.client;

import com.bluelock.game.BLCharacter;
import com.bluelock.net.Net;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

/** Экран 2: описание персонажа, его приёмы и кнопка «Выбрать». */
public class CharacterInfoScreen extends Screen {
	private final Screen parent;
	private final BLCharacter character;

	public CharacterInfoScreen(Screen parent, BLCharacter character) {
		super(Component.literal(character.displayName));
		this.parent = parent;
		this.character = character;
	}

	@Override
	protected void init() {
		int w = 148;
		int y = this.height - 30;
		this.addRenderableWidget(Button.builder(Component.literal("Выбрать"), b -> {
			ClientPlayNetworking.send(new Net.ChoosePayload(character.id));
			this.minecraft.setScreen(null);
		}).bounds(this.width / 2 - w - 2, y, w, 22).build());
		this.addRenderableWidget(Button.builder(Component.literal("Назад"),
			b -> this.minecraft.setScreen(parent)).bounds(this.width / 2 + 2, y, w, 22).build());
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		super.render(g, mouseX, mouseY, partialTick);
		int maxW = Math.min(this.width - 24, 300);
		int x = (this.width - maxW) / 2;
		int y = 10;

		g.drawCenteredString(this.font, character.displayName, this.width / 2, y, 0xFFD54F);
		y += 14;

		y = drawWrapped(g, character.description, x, y, maxW, 0xFFFFFF);
		y += 2;
		String stats = "Контроль " + stars(character.control)
			+ "  Сила " + stars(character.power / 1.35)
			+ "  Точность " + stars(character.accuracy);
		g.drawString(this.font, stats, x, y, 0x9FD3FF, false);
		y += 14;

		String[] keys = {"Z", "X", "C"};
		for (int i = 0; i < 3; i++) {
			BLCharacter.Skill s = character.skills[i];
			String head = "[" + keyLabel(i, keys[i]) + "] " + s.name() + " (" + (s.cooldownTicks() / 20) + " с)";
			g.drawString(this.font, head, x, y, 0x7CFC9A, false);
			y += 10;
			y = drawWrapped(g, s.desc(), x + 8, y, maxW - 8, 0xBBBBBB);
			y += 3;
		}
	}

	private String keyLabel(int slot, String fallback) {
		try {
			return switch (slot) {
				case 0 -> BlueLockClient.SKILL1.getTranslatedKeyMessage().getString();
				case 1 -> BlueLockClient.SKILL2.getTranslatedKeyMessage().getString();
				default -> BlueLockClient.SKILL3.getTranslatedKeyMessage().getString();
			};
		} catch (Exception e) {
			return fallback;
		}
	}

	private int drawWrapped(GuiGraphics g, String text, int x, int y, int maxW, int color) {
		List<FormattedCharSequence> lines = this.font.split(Component.literal(text), maxW);
		for (FormattedCharSequence line : lines) {
			g.drawString(this.font, line, x, y, color, false);
			y += 10;
		}
		return y;
	}

	private static String stars(double v) {
		int n = (int) Math.round(Math.max(0.0, Math.min(1.0, v)) * 5.0);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 5; i++) {
			sb.append(i < n ? '*' : '-');
		}
		return sb.toString();
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
