package com.bluelock.client;

import com.bluelock.net.Net;
import net.minecraft.client.Minecraft;

public final class ClientState {
	public static String character = "";
	/** Игровое время клиента, когда заканчивается кулдаун слота. */
	public static final long[] cdEnd = new long[3];

	private ClientState() {}

	public static void apply(Net.SyncPayload s) {
		character = s.id();
		long now = Minecraft.getInstance().level == null ? 0 : Minecraft.getInstance().level.getGameTime();
		cdEnd[0] = now + s.cd0();
		cdEnd[1] = now + s.cd1();
		cdEnd[2] = now + s.cd2();
	}

	public static long remaining(int slot) {
		if (Minecraft.getInstance().level == null) {
			return 0;
		}
		return Math.max(0, cdEnd[slot] - Minecraft.getInstance().level.getGameTime());
	}
}
