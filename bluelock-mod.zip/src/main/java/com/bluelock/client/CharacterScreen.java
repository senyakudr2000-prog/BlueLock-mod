package com.bluelock.client;

import com.bluelock.game.BLCharacter;
import com.bluelock.net.Net;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Экран 1: сетка персонажей + кнопка сброса. Крупные кнопки — удобно нажимать пальцем. */
public class CharacterScreen extends Screen {
	public CharacterScreen() {
		super(Component.literal("Blue Lock — выбери игрока"));
	}

	@Override
	protected void init() {
		BLCharacter[] all = BLCharacter.values();
		int cols = 3;
		int bw = 100;
		int bh = 22;
		int gap = 4;
		int totalW = cols * bw + (cols - 1) * gap;
		int x0 = (this.width - totalW) / 2;
		int y0 = 40;

		for (int i = 0; i < all.length; i++) {
			BLCharacter c = all[i];
			int cx = x0 + (i % cols) * (bw + gap);
			int cy = y0 + (i / cols) * (bh + gap);
			this.addRenderableWidget(Button.builder(Component.literal(c.shortName),
				b -> this.minecraft.setScreen(new CharacterInfoScreen(this, c)))
				.bounds(cx, cy, bw, bh).build());
		}

		int rows = (all.length + cols - 1) / cols;
		int by = y0 + rows * (bh + gap) + 6;
		this.addRenderableWidget(Button.builder(Component.literal("Сбросить"), b -> {
			ClientPlayNetworking.send(new Net.ChoosePayload(""));
			this.onClose();
		}).bounds(x0, by, 148, 22).build());
		this.addRenderableWidget(Button.builder(Component.literal("Закрыть"), b -> this.onClose())
			.bounds(x0 + 152, by, 148, 22).build());
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
		super.render(g, mouseX, mouseY, partialTick);
		g.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFF);
		BLCharacter cur = BLCharacter.byId(ClientState.character);
		String now = cur == null ? "Сейчас: персонаж не выбран" : "Сейчас: " + cur.displayName;
		g.drawCenteredString(this.font, now, this.width / 2, 26, 0xFFD54F);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
