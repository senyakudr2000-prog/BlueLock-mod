package com.bluelock.client;

import com.bluelock.game.BLCharacter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.KeyMapping;

public final class Hud {
	private Hud() {}

	public static void render(GuiGraphics g) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null || mc.options.hideGui) {
			return;
		}
		int x = 6;
		int y = 6;
		BLCharacter ch = BLCharacter.byId(ClientState.character);
		if (ch == null) {
			g.drawString(mc.font, "Blue Lock: персонаж не выбран — ПКМ по «Меню Blue Lock» / клавиша "
				+ label(BlueLockClient.MENU), x, y, 0xFFFFFF, true);
		} else {
			g.drawString(mc.font, ch.displayName, x, y, 0xFFD54F, true);
			y += 11;
			KeyMapping[] keys = {BlueLockClient.SKILL1, BlueLockClient.SKILL2, BlueLockClient.SKILL3};
			for (int i = 0; i < 3; i++) {
				long rem = ClientState.remaining(i);
				String status = rem > 0 ? String.format(" (%.1f с)", rem / 20.0) : " — готово";
				int color = rem > 0 ? 0xFF8888 : 0x88FF99;
				g.drawString(mc.font, label(keys[i]) + ": " + ch.skills[i].name() + status, x, y, color, true);
				y += 10;
			}
		}

		// шкала заряда удара
		int charge = BlueLockClient.charge;
		if (charge > 0) {
			int w = 80;
			int bx = mc.getWindow().getGuiScaledWidth() / 2 - w / 2;
			int by = mc.getWindow().getGuiScaledHeight() - 58;
			g.fill(bx - 1, by - 1, bx + w + 1, by + 5, 0xFF000000);
			int filled = (int) (w * (charge / 20.0));
			int color = charge >= 18 ? 0xFFFF4040 : 0xFFFFD040;
			g.fill(bx, by, bx + filled, by + 4, color);
		}
	}

	private static String label(KeyMapping k) {
		return k.getTranslatedKeyMessage().getString();
	}
}
