package com.bluelock.net;

import com.bluelock.BlueLockMod;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;

public final class Net {
	private Net() {}

	// ---- анимации (id) ----
	public static final int ANIM_KICK = 0;
	public static final int ANIM_POWER = 1;
	public static final int ANIM_STEP = 2;
	public static final int ANIM_DASH = 3;
	public static final int ANIM_TRAP = 4;

	// ---- действия клиента -> сервер ----
	public static final int ACT_SHOOT = 0;
	public static final int ACT_PASS = 1;
	public static final int ACT_LOB = 2;
	public static final int ACT_SKILL = 3;
	public static final int ACT_TRAP = 4;

	/** Клиент -> сервер: удар / пас / навес / приём / приём мяча. */
	public record ActionPayload(int action, int arg) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<ActionPayload> TYPE =
			new CustomPacketPayload.Type<>(BlueLockMod.id("action"));
		public static final StreamCodec<RegistryFriendlyByteBuf, ActionPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, ActionPayload::action,
			ByteBufCodecs.VAR_INT, ActionPayload::arg,
			ActionPayload::new);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Клиент -> сервер: выбор персонажа ("" = сброс). */
	public record ChoosePayload(String id) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<ChoosePayload> TYPE =
			new CustomPacketPayload.Type<>(BlueLockMod.id("choose"));
		public static final StreamCodec<RegistryFriendlyByteBuf, ChoosePayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.STRING_UTF8, ChoosePayload::id,
			ChoosePayload::new);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Сервер -> клиент: текущий персонаж и оставшиеся кулдауны (в тиках). */
	public record SyncPayload(String id, int cd0, int cd1, int cd2) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<SyncPayload> TYPE =
			new CustomPacketPayload.Type<>(BlueLockMod.id("sync"));
		public static final StreamCodec<RegistryFriendlyByteBuf, SyncPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.STRING_UTF8, SyncPayload::id,
			ByteBufCodecs.VAR_INT, SyncPayload::cd0,
			ByteBufCodecs.VAR_INT, SyncPayload::cd1,
			ByteBufCodecs.VAR_INT, SyncPayload::cd2,
			SyncPayload::new);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Сервер -> клиенты рядом: проиграть анимацию у игрока. */
	public record AnimPayload(int entityId, int anim) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<AnimPayload> TYPE =
			new CustomPacketPayload.Type<>(BlueLockMod.id("anim"));
		public static final StreamCodec<RegistryFriendlyByteBuf, AnimPayload> CODEC = StreamCodec.composite(
			ByteBufCodecs.VAR_INT, AnimPayload::entityId,
			ByteBufCodecs.VAR_INT, AnimPayload::anim,
			AnimPayload::new);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	public static void registerPayloads() {
		PayloadTypeRegistry.playC2S().register(ActionPayload.TYPE, ActionPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(ChoosePayload.TYPE, ChoosePayload.CODEC);
		PayloadTypeRegistry.playS2C().register(SyncPayload.TYPE, SyncPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(AnimPayload.TYPE, AnimPayload.CODEC);
	}

	/** Анимация у игрока: видят он сам и все, кто его отслеживает. */
	public static void sendAnim(ServerPlayer player, int anim) {
		AnimPayload payload = new AnimPayload(player.getId(), anim);
		ServerPlayNetworking.send(player, payload);
		for (ServerPlayer other : PlayerLookup.tracking(player)) {
			ServerPlayNetworking.send(other, payload);
		}
	}
}
