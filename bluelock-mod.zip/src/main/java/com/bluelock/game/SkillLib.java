package com.bluelock.game;

import com.bluelock.entity.BallEntity;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Набор "кирпичиков", из которых собраны приёмы персонажей. */
public final class SkillLib {
	private SkillLib() {}

	// ------------------------------------------------------------ утилиты

	public static Vec3 flat(Vec3 v) {
		double l = Math.sqrt(v.x * v.x + v.z * v.z);
		return l < 1.0E-4 ? new Vec3(0, 0, 1) : new Vec3(v.x / l, 0, v.z / l);
	}

	public static boolean noBall(ServerPlayer p) {
		p.displayClientMessage(Component.literal("Рядом нет мяча"), true);
		return false;
	}

	public static void effect(ServerPlayer p, Holder<MobEffect> eff, int ticks, int amp) {
		p.addEffect(new MobEffectInstance(eff, ticks, amp, false, false, true));
	}

	public static void burst(ServerPlayer p, ParticleOptions particle, int count) {
		p.serverLevel().sendParticles(particle, p.getX(), p.getY() + 1.0, p.getZ(), count, 0.4, 0.5, 0.4, 0.05);
	}

	/** Мгновенный рывок игрока в направлении dir. */
	public static void dash(ServerPlayer p, Vec3 dir, double speed) {
		Vec3 d = flat(dir);
		p.setDeltaMovement(d.x * speed, Math.max(p.getDeltaMovement().y, 0.1), d.z * speed);
		p.hurtMarked = true;
	}

	/** Мяч прилипает к ногам на ticks тиков. */
	public static void magnet(ServerPlayer p, PlayerState.Data d, long now, int ticks, boolean weave, double weaveAmp) {
		d.magnetUntil = now + ticks;
		d.weave = weave;
		d.weaveAmp = weaveAmp;
	}

	/** Оттолкнуть всех живых существ рядом (кроме себя). */
	public static void shove(ServerPlayer p, double radius, double strength, boolean frontOnly) {
		Vec3 look = flat(p.getLookAngle());
		AABB box = p.getBoundingBox().inflate(radius, 1.0, radius);
		List<LivingEntity> list = p.level().getEntitiesOfClass(LivingEntity.class, box, e -> e != p);
		for (LivingEntity e : list) {
			Vec3 rel = e.position().subtract(p.position());
			Vec3 relFlat = flat(rel);
			if (frontOnly && relFlat.dot(look) < 0.3) {
				continue;
			}
			e.push(relFlat.x * strength, 0.25, relFlat.z * strength);
			e.hurtMarked = true;
		}
	}

	// ------------------------------------------------------------ удары

	/**
	 * Прицельный удар в направлении взгляда.
	 * lift — добавка вверх к направлению, spin — закрутка (знак = в какую сторону).
	 */
	public static boolean shot(ServerPlayer p, double reach, double speed, float spin, double lift) {
		BallEntity b = BallEntity.nearest(p, reach);
		if (b == null) {
			return noBall(p);
		}
		Vec3 look = p.getLookAngle();
		Vec3 dir = new Vec3(look.x, look.y + lift, look.z).normalize();
		b.launch(dir.scale(speed), spin);
		return true;
	}

	/** Удар с лёта: работает только если мяч в воздухе. */
	public static boolean volley(ServerPlayer p, double reach, double speed) {
		BallEntity b = BallEntity.nearest(p, reach);
		if (b == null) {
			return noBall(p);
		}
		if (b.onGround()) {
			p.displayClientMessage(Component.literal("Мяч должен быть в воздухе"), true);
			return false;
		}
		b.launch(p.getLookAngle().normalize().scale(speed), 0f);
		return true;
	}

	/** Навес вперёд (дуга над защитником). */
	public static boolean chip(ServerPlayer p, double reach, double speed, double up) {
		BallEntity b = BallEntity.nearest(p, reach);
		if (b == null) {
			return noBall(p);
		}
		Vec3 f = flat(p.getLookAngle());
		b.launch(new Vec3(f.x * speed, up, f.z * speed), 0f);
		return true;
	}

	/** Идеальный приём: гасит скорость и подкатывает мяч к ногам. */
	public static boolean trap(ServerPlayer p, double reach) {
		BallEntity b = BallEntity.nearest(p, reach);
		if (b == null) {
			return noBall(p);
		}
		Vec3 f = flat(p.getLookAngle());
		b.trapTo(new Vec3(p.getX() + f.x * 0.6, p.getY(), p.getZ() + f.z * 0.6));
		return true;
	}

	/** Мяч в сторону (финт-обводка). side = +1 / -1. */
	public static boolean slide(ServerPlayer p, double reach, double power, int side) {
		BallEntity b = BallEntity.nearest(p, reach);
		if (b == null) {
			return noBall(p);
		}
		Vec3 f = flat(p.getLookAngle());
		Vec3 s = new Vec3(-f.z * side, 0, f.x * side);
		b.launch(new Vec3(s.x * power + f.x * 0.15, 0.05, s.z * power + f.z * 0.15), 0f);
		dash(p, s.add(f.scale(0.4)), power * 0.9);
		return true;
	}

	/** Точный пас ближайшему игроку в секторе взгляда. */
	public static boolean passToTeammate(ServerPlayer p, double reach) {
		BallEntity b = BallEntity.nearest(p, reach);
		if (b == null) {
			return noBall(p);
		}
		Vec3 look = flat(p.getLookAngle());
		ServerPlayer best = null;
		double bestDist = 40.0 * 40.0;
		for (ServerPlayer other : p.serverLevel().players()) {
			if (other == p || other.isSpectator()) {
				continue;
			}
			Vec3 rel = other.position().subtract(p.position());
			double d = rel.lengthSqr();
			if (d < bestDist && flat(rel).dot(look) > 0.8) {
				bestDist = d;
				best = other;
			}
		}
		if (best == null) {
			b.launch(new Vec3(look.x * 1.1, 0.12, look.z * 1.1), 0f);
			return true;
		}
		Vec3 to = best.position().subtract(b.position());
		double dist = Math.sqrt(to.x * to.x + to.z * to.z);
		double speed = Math.min(1.8, 0.45 + dist * 0.07);
		Vec3 f = flat(to);
		b.launch(new Vec3(f.x * speed, 0.1 + dist * 0.004, f.z * speed), 0f);
		return true;
	}

	/** Притянуть все мячи в радиусе к ногам и оттолкнуть соперников ("пожиратель"). */
	public static boolean devour(ServerPlayer p, double radius) {
		List<BallEntity> balls = p.level().getEntitiesOfClass(BallEntity.class, p.getBoundingBox().inflate(radius));
		if (balls.isEmpty()) {
			return noBall(p);
		}
		Vec3 f = flat(p.getLookAngle());
		for (BallEntity b : balls) {
			b.trapTo(new Vec3(p.getX() + f.x * 0.6, p.getY(), p.getZ() + f.z * 0.6));
		}
		shove(p, 3.0, 1.1, false);
		return true;
	}
}
