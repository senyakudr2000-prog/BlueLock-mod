package com.bluelock.game;

import com.bluelock.entity.BallEntity;
import com.bluelock.entity.ModEntities;
import com.bluelock.item.ModItems;
import com.bluelock.net.Net;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public final class ServerEvents {
	private ServerEvents() {}

	public static void register() {
		// --- сетевые приёмники
		ServerPlayNetworking.registerGlobalReceiver(Net.ActionPayload.TYPE, (payload, ctx) -> {
			ServerPlayer p = ctx.player();
			ctx.server().execute(() -> handleAction(p, payload.action(), payload.arg()));
		});
		ServerPlayNetworking.registerGlobalReceiver(Net.ChoosePayload.TYPE, (payload, ctx) -> {
			ServerPlayer p = ctx.player();
			ctx.server().execute(() -> {
				BLCharacter c = BLCharacter.byId(payload.id());
				PlayerState.setCharacter(p, c);
				if (c == null) {
					p.displayClientMessage(Component.literal("Персонаж сброшен. Выбери нового в меню."), true);
				} else {
					p.displayClientMessage(Component.literal("Ты теперь " + c.displayName), true);
				}
			});
		});

		// --- вход игрока: выдаём набор и синхронизируем состояние
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayer p = handler.getPlayer();
			if (!p.getTags().contains("bl_kit")) {
				p.addTag("bl_kit");
				p.getInventory().add(new ItemStack(ModItems.MENU));
				p.getInventory().add(new ItemStack(ModItems.FOOTBALL));
				p.displayClientMessage(Component.literal("Blue Lock: ПКМ по «Меню Blue Lock» — выбор персонажа"), false);
			}
			PlayerState.sync(p);
		});

		// --- респавн: теги копируем явно, на всякий случай, и шлём синхронизацию
		ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> {
			for (String tag : oldPlayer.getTags()) {
				newPlayer.addTag(tag);
			}
		});
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> PlayerState.sync(newPlayer));

		// --- пассивки персонажей
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTickCount() % 20 != 0) {
				return;
			}
			for (ServerPlayer p : server.getPlayerList().getPlayers()) {
				BLCharacter c = PlayerState.character(p);
				if (c != null && c.speedAmp >= 0) {
					p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, c.speedAmp, true, false, false));
				}
			}
		});

		// --- команды (запасной вариант без меню)
		CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) -> dispatcher.register(
			Commands.literal("bluelock")
				.then(Commands.literal("ball").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					spawnBall(p);
					return 1;
				}))
				.then(Commands.literal("kit").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					p.getInventory().add(new ItemStack(ModItems.MENU));
					p.getInventory().add(new ItemStack(ModItems.FOOTBALL));
					return 1;
				}))
				.then(Commands.literal("reset").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					PlayerState.setCharacter(p, null);
					return 1;
				}))
				.then(Commands.literal("choose").then(
					Commands.argument("id", StringArgumentType.word()).executes(ctx -> {
						ServerPlayer p = ctx.getSource().getPlayerOrException();
						BLCharacter c = BLCharacter.byId(StringArgumentType.getString(ctx, "id"));
						if (c == null) {
							StringBuilder ids = new StringBuilder();
							for (BLCharacter ch : BLCharacter.values()) {
								ids.append(ch.id).append(' ');
							}
							ctx.getSource().sendFailure(Component.literal("Неизвестный персонаж. Доступны: " + ids));
							return 0;
						}
						PlayerState.setCharacter(p, c);
						return 1;
					})))
		));
	}

	private static void spawnBall(ServerPlayer p) {
		ServerLevel level = p.serverLevel();
		BallEntity ball = ModEntities.BALL.create(level);
		if (ball == null) {
			return;
		}
		Vec3 look = p.getLookAngle();
		ball.setPos(p.getX() + look.x * 1.5, p.getY() + 0.5, p.getZ() + look.z * 1.5);
		level.addFreshEntity(ball);
	}

	private static void handleAction(ServerPlayer p, int action, int arg) {
		PlayerState.Data d = PlayerState.data(p);
		long now = p.level().getGameTime();
		// защита от спама пакетами
		if (now - d.lastActionTick < 2) {
			return;
		}
		d.lastActionTick = now;

		switch (action) {
			case Net.ACT_SHOOT -> BallEntity.playerKick(p, clamp(arg, 0, 100) / 100.0, BallEntity.KICK_SHOT);
			case Net.ACT_PASS -> BallEntity.playerKick(p, 0.55, BallEntity.KICK_PASS);
			case Net.ACT_LOB -> BallEntity.playerKick(p, 0.6, BallEntity.KICK_LOB);
			case Net.ACT_SKILL -> PlayerState.cast(p, clamp(arg, 0, 2));
			case Net.ACT_TRAP -> {
				Net.sendAnim(p, Net.ANIM_TRAP);
				SkillLib.trap(p, 3.5);
			}
			default -> {
			}
		}
	}

	private static int clamp(int v, int lo, int hi) {
		return Math.max(lo, Math.min(hi, v));
	}
}
