package com.bluelock.game;

import com.bluelock.entity.BallEntity;
import com.bluelock.net.Net;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Персонажи Blue Lock. У каждого: характеристики (контроль мяча, сила и точность удара),
 * опциональная пассивка и три приёма (клавиши "Приём 1/2/3").
 * Кулдауны указаны в тиках (20 тиков = 1 секунда).
 */
public enum BLCharacter {

	ISAGI("isagi", "Исаги Ёичи", "Исаги",
		"Хищник, читающий поле. Бьёт точно и с лёта, видит всех игроков на поле.",
		-1, 0.60, 1.00, 0.90,
		new Skill("Прямой удар", "Мощный точный удар; с лёта (мяч в воздухе) — ещё сильнее.", 160, Net.ANIM_POWER,
			(p, d, now) -> {
				BallEntity b = BallEntity.nearest(p, 3.5);
				if (b == null) {
					return SkillLib.noBall(p);
				}
				boolean air = !b.onGround();
				return SkillLib.shot(p, 3.5, air ? 2.2 : 1.7, 0f, 0.04);
			}),
		new Skill("Метавидение", "8 с: ускорение, все игроки в 25 блоках подсвечены.", 400, Net.ANIM_DASH,
			(p, d, now) -> {
				SkillLib.effect(p, MobEffects.MOVEMENT_SPEED, 160, 1);
				for (ServerPlayer other : p.serverLevel().players()) {
					if (other != p && other.distanceToSqr(p) < 625.0) {
						SkillLib.effect(other, MobEffects.GLOWING, 120, 0);
					}
				}
				SkillLib.burst(p, ParticleTypes.END_ROD, 25);
				return true;
			}),
		new Skill("Изогнутый удар", "Сильный удар с закруткой — мяч огибает преграды.", 500, Net.ANIM_POWER,
			(p, d, now) -> SkillLib.shot(p, 3.5, 2.0, 0.9f, 0.10))
	),

	BACHIRA("bachira", "Бачира Мегуру", "Бачира",
		"Дриблёр-«монстр». Мяч липнет к ногам, обводит непредсказуемо.",
		0, 0.95, 0.90, 0.70,
		new Skill("Монстр-дриблинг", "4 с: мяч прилипает к ногам и виляет зигзагом, ускорение.", 240, Net.ANIM_DASH,
			(p, d, now) -> {
				if (BallEntity.nearest(p, 6.0) == null) {
					return SkillLib.noBall(p);
				}
				SkillLib.magnet(p, d, now, 80, true, 0.35);
				SkillLib.effect(p, MobEffects.MOVEMENT_SPEED, 80, 2);
				SkillLib.burst(p, ParticleTypes.ENCHANT, 25);
				return true;
			}),
		new Skill("Нутмег-проброс", "Мяч уходит вперёд, ты следом рывком.", 140, Net.ANIM_STEP,
			(p, d, now) -> {
				BallEntity b = BallEntity.nearest(p, 3.0);
				if (b == null) {
					return SkillLib.noBall(p);
				}
				Vec3 f = SkillLib.flat(p.getLookAngle());
				b.launch(new Vec3(f.x * 1.1, 0.05, f.z * 1.1), 0f);
				SkillLib.dash(p, f, 1.0);
				SkillLib.magnet(p, d, now, 40, false, 0);
				return true;
			}),
		new Skill("Режим Монстра", "10 с: мяч намертво у ног, зигзаги, скорость и прыжок.", 500, Net.ANIM_DASH,
			(p, d, now) -> {
				SkillLib.magnet(p, d, now, 200, true, 0.5);
				SkillLib.effect(p, MobEffects.MOVEMENT_SPEED, 200, 3);
				SkillLib.effect(p, MobEffects.JUMP, 200, 1);
				SkillLib.burst(p, ParticleTypes.SOUL_FIRE_FLAME, 40);
				return true;
			})
	),

	NAGI("nagi", "Наги Сэйсиро", "Наги",
		"Гений контроля. Пассивка: автоматически гасит быстрые мячи у ног (идеальный трап).",
		-1, 0.80, 1.00, 0.95,
		new Skill("Идеальный трап", "Мгновенно останавливает мяч в 7 блоках и подкатывает к ногам.", 60, Net.ANIM_TRAP,
			(p, d, now) -> SkillLib.trap(p, 7.0)),
		new Skill("Скип-тач", "Подбрасывает мяч дугой вперёд — над защитником.", 100, Net.ANIM_TRAP,
			(p, d, now) -> SkillLib.chip(p, 3.0, 0.55, 0.65)),
		new Skill("Удар с лёта", "Мощный удар по мячу в воздухе (мяч должен лететь).", 360, Net.ANIM_POWER,
			(p, d, now) -> SkillLib.volley(p, 4.5, 2.2))
	),

	CHIGIRI("chigiri", "Чигири Хёма", "Чигири",
		"Молниеносный спринтер. Пассивка: постоянное ускорение.",
		1, 0.70, 0.95, 0.80,
		new Skill("Алый спринт", "3 с: огромная скорость, мяч у ног.", 200, Net.ANIM_DASH,
			(p, d, now) -> {
				SkillLib.effect(p, MobEffects.MOVEMENT_SPEED, 60, 4);
				SkillLib.dash(p, p.getLookAngle(), 0.9);
				SkillLib.magnet(p, d, now, 60, false, 0);
				SkillLib.burst(p, ParticleTypes.FLAME, 25);
				return true;
			}),
		new Skill("Красный кросс", "Низкая резкая передача на всю длину поля.", 140, Net.ANIM_KICK,
			(p, d, now) -> SkillLib.shot(p, 3.5, 1.6, 0f, 0.02)),
		new Skill("Метеор", "2 с: сверхскорость, сносит соперников на пути.", 500, Net.ANIM_DASH,
			(p, d, now) -> {
				SkillLib.effect(p, MobEffects.MOVEMENT_SPEED, 40, 6);
				SkillLib.dash(p, p.getLookAngle(), 1.4);
				SkillLib.shove(p, 2.5, 0.8, true);
				SkillLib.magnet(p, d, now, 40, false, 0);
				SkillLib.burst(p, ParticleTypes.FLAME, 40);
				return true;
			})
	),

	RIN("rin", "Итоши Рин", "Рин",
		"Идеальная техника. Самый точный и сильный бьющий, мастер финтов и пасов.",
		-1, 0.90, 1.15, 1.00,
		new Skill("Прямой выстрел", "Сверхточный сильный удар в направлении взгляда.", 120, Net.ANIM_POWER,
			(p, d, now) -> SkillLib.shot(p, 3.5, 2.1, 0f, 0.03)),
		new Skill("Финт-обводка", "Уводит мяч в сторону (стороны чередуются) и обходит соперника.", 100, Net.ANIM_STEP,
			(p, d, now) -> {
				d.flip = !d.flip;
				return SkillLib.slide(p, 3.0, 0.55, d.flip ? 1 : -1);
			}),
		new Skill("Кукловод", "Идеальный пас ближайшему игроку в секторе взгляда.", 160, Net.ANIM_KICK,
			(p, d, now) -> SkillLib.passToTeammate(p, 3.5))
	),

	BAROU("barou", "Бароу Сёэй", "Бароу",
		"Король эго. Грубая сила: самые мощные удары и силовая игра.",
		-1, 0.55, 1.35, 0.65,
		new Skill("Удар Короля", "Чудовищный по силе удар.", 200, Net.ANIM_POWER,
			(p, d, now) -> {
				boolean ok = SkillLib.shot(p, 3.5, 2.4, 0f, 0.05);
				if (ok) {
					SkillLib.burst(p, ParticleTypes.CRIT, 25);
				}
				return ok;
			}),
		new Skill("Пожиратель", "Забирает мяч в 6 блоках к себе и отшвыривает соперников.", 240, Net.ANIM_TRAP,
			(p, d, now) -> SkillLib.devour(p, 6.0)),
		new Skill("Натиск", "Рывок плечом: сносит всех впереди, ты получаешь сопротивление урону.", 400, Net.ANIM_DASH,
			(p, d, now) -> {
				SkillLib.effect(p, MobEffects.DAMAGE_RESISTANCE, 60, 1);
				SkillLib.dash(p, p.getLookAngle(), 1.2);
				SkillLib.shove(p, 3.5, 1.4, true);
				SkillLib.magnet(p, d, now, 40, false, 0);
				SkillLib.burst(p, ParticleTypes.CRIT, 25);
				return true;
			})
	),

	KUNIGAMI("kunigami", "Кунигами Рэнсукэ", "Кунигами",
		"Герой-таран. Сильные прямые удары, упорство и мощь.",
		-1, 0.55, 1.25, 0.85,
		new Skill("Удар Героя", "Сильный прямой удар по низкой траектории.", 160, Net.ANIM_POWER,
			(p, d, now) -> SkillLib.shot(p, 3.5, 2.0, 0f, -0.02)),
		new Skill("Железная воля", "8 с: сопротивление урону, мяч держится у ног.", 360, Net.ANIM_DASH,
			(p, d, now) -> {
				SkillLib.effect(p, MobEffects.DAMAGE_RESISTANCE, 160, 1);
				SkillLib.magnet(p, d, now, 100, false, 0);
				SkillLib.burst(p, ParticleTypes.CRIT, 15);
				return true;
			}),
		new Skill("Удар через себя", "Прыжок и удар через себя по мячу рядом.", 440, Net.ANIM_POWER,
			(p, d, now) -> {
				BallEntity b = BallEntity.nearest(p, 4.0);
				if (b == null) {
					return SkillLib.noBall(p);
				}
				Vec3 dm = p.getDeltaMovement();
				p.setDeltaMovement(dm.x, 0.75, dm.z);
				p.hurtMarked = true;
				Vec3 look = p.getLookAngle();
				b.launch(new Vec3(look.x * 1.8, 0.35, look.z * 1.8), 0f);
				return true;
			})
	),

	REO("reo", "Микагэ Рэо", "Рэо",
		"Хамелеон. Копирует приёмы других игроков рядом (или случайного персонажа).",
		-1, 0.70, 1.00, 0.90,
		new Skill("Хамелеон I", "Копирует приём 1 ближайшего игрока (или случайного героя).", 200, Net.ANIM_KICK,
			(p, d, now) -> mimic(p, d, now, 0)),
		new Skill("Хамелеон II", "Копирует приём 2 ближайшего игрока (или случайного героя).", 260, Net.ANIM_KICK,
			(p, d, now) -> mimic(p, d, now, 1)),
		new Skill("Хамелеон III", "Копирует приём 3 ближайшего игрока (или случайного героя).", 500, Net.ANIM_KICK,
			(p, d, now) -> mimic(p, d, now, 2))
	);

	// ------------------------------------------------------------------

	@FunctionalInterface
	public interface SkillAction {
		/** @return true, если приём сработал (тогда включается кулдаун). */
		boolean run(ServerPlayer p, PlayerState.Data d, long now);
	}

	public record Skill(String name, String desc, int cooldownTicks, int anim, SkillAction action) {}

	public final String id;
	public final String displayName;
	public final String shortName;
	public final String description;
	/** Пассивное ускорение: -1 нет, иначе уровень эффекта скорости. */
	public final int speedAmp;
	/** Контроль мяча при дриблинге 0..1. */
	public final double control;
	/** Множитель силы удара. */
	public final double power;
	/** Точность удара 0..1. */
	public final double accuracy;
	public final Skill[] skills;

	BLCharacter(String id, String displayName, String shortName, String description,
				int speedAmp, double control, double power, double accuracy, Skill... skills) {
		this.id = id;
		this.displayName = displayName;
		this.shortName = shortName;
		this.description = description;
		this.speedAmp = speedAmp;
		this.control = control;
		this.power = power;
		this.accuracy = accuracy;
		this.skills = skills;
	}

	public static BLCharacter byId(String id) {
		if (id == null || id.isEmpty()) {
			return null;
		}
		for (BLCharacter c : values()) {
			if (c.id.equals(id)) {
				return c;
			}
		}
		return null;
	}

	private static boolean mimic(ServerPlayer p, PlayerState.Data d, long now, int slot) {
		BLCharacter pick = null;
		double best = 30.0 * 30.0;
		for (ServerPlayer other : p.serverLevel().players()) {
			if (other == p) {
				continue;
			}
			BLCharacter oc = PlayerState.character(other);
			double dist = other.distanceToSqr(p);
			if (oc != null && oc != REO && dist < best) {
				best = dist;
				pick = oc;
			}
		}
		if (pick == null) {
			List<BLCharacter> pool = new ArrayList<>();
			for (BLCharacter c : values()) {
				if (c != REO) {
					pool.add(c);
				}
			}
			pick = pool.get(p.getRandom().nextInt(pool.size()));
		}
		Skill s = pick.skills[slot];
		p.displayClientMessage(Component.literal("Хамелеон копирует: " + pick.shortName + " — " + s.name()), true);
		return s.action().run(p, d, now);
	}
}
