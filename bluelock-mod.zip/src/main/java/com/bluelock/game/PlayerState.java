package com.bluelock.game;

import com.bluelock.net.Net;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Выбранный персонаж хранится в тегах игрока ("blc_<id>") — они сохраняются в мире,
 * переживают перезаход и респавн. Кулдауны и временные эффекты — в памяти сервера.
 */
public final class PlayerState {
	private static final String TAG_PREFIX = "blc_";
	private static final Map<UUID, Data> DATA = new HashMap<>();

	private PlayerState() {}

	public static final class Data {
		public final long[] cdEnd = new long[3];
		public long magnetUntil = 0;
		public boolean weave = false;
		public double weaveAmp = 0.35;
		public boolean flip = false;
		public long lastActionTick = 0;
	}

	public static Data data(Player p) {
		return DATA.computeIfAbsent(p.getUUID(), k -> new Data());
	}

	public static BLCharacter character(Player p) {
		for (String tag : p.getTags()) {
			if (tag.startsWith(TAG_PREFIX)) {
				BLCharacter c = BLCharacter.byId(tag.substring(TAG_PREFIX.length()));
				if (c != null) {
					return c;
				}
			}
		}
		return null;
	}

	public static void setCharacter(ServerPlayer p, BLCharacter c) {
		for (String tag : new ArrayList<>(p.getTags())) {
			if (tag.startsWith(TAG_PREFIX)) {
				p.removeTag(tag);
			}
		}
		if (c != null) {
			p.addTag(TAG_PREFIX + c.id);
		}
		DATA.put(p.getUUID(), new Data());
		sync(p);
	}

	public static void sync(ServerPlayer p) {
		BLCharacter c = character(p);
		Data d = data(p);
		long now = p.level().getGameTime();
		ServerPlayNetworking.send(p, new Net.SyncPayload(
			c == null ? "" : c.id,
			remaining(d.cdEnd[0], now),
			remaining(d.cdEnd[1], now),
			remaining(d.cdEnd[2], now)));
	}

	private static int remaining(long end, long now) {
		return (int) Math.max(0, end - now);
	}

	/** Применить приём слота 0..2 (с проверкой кулдауна). */
	public static void cast(ServerPlayer p, int slot) {
		BLCharacter c = character(p);
		if (c == null) {
			p.displayClientMessage(Component.literal("Сначала выбери персонажа (предмет «Меню Blue Lock»)"), true);
			return;
		}
		Data d = data(p);
		long now = p.level().getGameTime();
		if (now < d.cdEnd[slot]) {
			double sec = (d.cdEnd[slot] - now) / 20.0;
			p.displayClientMessage(Component.literal(
				c.skills[slot].name() + ": перезарядка " + String.format("%.1f", sec) + " с"), true);
			return;
		}
		BLCharacter.Skill skill = c.skills[slot];
		boolean ok = skill.action().run(p, d, now);
		if (ok) {
			d.cdEnd[slot] = now + skill.cooldownTicks();
			Net.sendAnim(p, skill.anim());
			p.displayClientMessage(Component.literal("⚽ " + skill.name()), true);
			sync(p);
		}
	}
}
