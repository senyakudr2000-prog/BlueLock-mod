package com.bluelock;

import com.bluelock.game.ServerEvents;
import com.bluelock.item.ModItems;
import com.bluelock.entity.ModEntities;
import com.bluelock.net.Net;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.ResourceLocation;

public class BlueLockMod implements ModInitializer {
	public static final String MOD_ID = "bluelock";

	/** Клиент подставляет сюда открытие меню (общий код не должен ссылаться на клиентские классы). */
	public static Runnable OPEN_MENU = () -> {};

	public static ResourceLocation id(String path) {
		return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModEntities.register();
		ModItems.register();
		Net.registerPayloads();
		ServerEvents.register();
	}
}
